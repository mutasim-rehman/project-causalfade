# Independent blind review · Cohort 29

Review the 32 causal prompts in blind_review.json and the four worked cases in
worked-cases.md. Record each choice in answers.csv with 0 for off or 1 for on.
Note ambiguity or missing assumptions in the notes column. For the worked
cases, solve all four randomized-source and target-mix combinations per case,
and verify that the same choices follow when that source is designated for the
arithmetic control. The four cases are outside the collection schedule.

Record your name, review date, and declaration of independence and exposure.
Seal your completed answers and observations before accessing the design map or
any answer key. Keep any reconciliation as a separate record afterwards.

Exact transfer.json SHA-256: 48bb313e7d02fcfe5f17b99739fb33f84c1803e6127e6add6488115f0e8123c5
Exact blind_review.json SHA-256: a4f0dbbe09114fb5624d84542b8aab4d3f452af9c06ad277c177a6fce49873ba
Candidate tasks.jsonl SHA-256: a279fa2939c6a58d843b108e1312428c1f6fa9738153a750fdddfb9d979778e5

# Four worked cases for blinded review

Every off rate is 50%. Each pair of on rates is ordered as stratum S=1, S=0.
The target weights for S=1 are 55% (low) and 80% (high). The remaining
share is S=0. Treat L as randomized and R as historical, then reverse
the roles. Assume the randomized study's stratum effects transfer to
each target. Choose the setting with higher target success for each
combination. For the arithmetic control, use the designated table
in place of the randomized one and compare the weighted on and off totals.

| Case | L on rates (%) | R on rates (%) |
| --- | --- | --- |
| 1 | 53, 44 | 45.5, 58 |
| 2 | 56, 47 | 45, 52 |
| 3 | 56, 47 | 55, 48 |
| 4 | 53, 44 | 53.5, 44 |
